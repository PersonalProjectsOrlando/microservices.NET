package com.oralbama.exampleDocker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExampleDockerApplicationTests {

	@Test
	void contextLoads() {
	}

}
