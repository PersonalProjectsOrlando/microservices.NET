package com.oralbama.exampleDocker;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExampleDockerApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExampleDockerApplication.class, args);
	}

}
